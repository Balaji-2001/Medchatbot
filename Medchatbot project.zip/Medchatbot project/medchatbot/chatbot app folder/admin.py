from django.contrib import admin
from .models import MedicalInfo

admin.site.register(MedicalInfo)
